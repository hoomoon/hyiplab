ALTER TABLE `users` ADD `is_deleted` TINYINT(1) NOT NULL DEFAULT '0' AFTER `status`;
